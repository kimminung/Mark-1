//
//  AppDelegate.swift
//  Class20180528
//
//  Created by H on 2018. 5. 28..
//  Copyright © 2018년 H. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
////                let window = UIWindow(frame: CGRect())
//        let window = UIWindow(frame: UIScreen.main.bounds)
//        //        CGRect(x: 0, y: 0, width: <#T##CGFloat#>, height: <#T##CGFloat#>//Window 생성
//
//        window.rootViewController = ViewController() //VeiwController 지정
//        window.backgroundColor = UIColor.white //색상지정
//        window.makeKeyAndVisible() //Keywindow 지정
//        self.window = window
//
//        let window = UIWindow(frame: UIScreen.main.bounds)
//        window.rootViewController = ViewController()
//        window.backgroundColor = UIColor.red
//        window.makeKeyAndVisible()
//        self.window = window
//
//        let window = UIWindow(frame: UIScreen.main.bounds)
//        let viewController = ViewController()
//        window.rootViewController = viewController
//        
//        window.backgroundColor = UIColor.white
//        window.makeKeyAndVisible()
//        self.window = window
        
        return true
    }
}
//
//    func applicationWillResignActive(_ application: UIApplication) {
//        print("applicationWillResignActive")
//
//    }
//
//    func applicationDidEnterBackground(_ application: UIApplication) {
//        print("applicationDidEnterBackground")
//    }
//
//    func applicationWillEnterForeground(_ application: UIApplication) {
//        print("applicationWillenterForeground")
//
//    }
//
//    func applicationDidBecomeActive(_ application: UIApplication) {
//        print("applicationDidBecomeActive")
//
//    }
//
//    func applicationWillTerminate(_ application: UIApplication) {
//        print("applicationWillTerminate")
//
//    }
//
//
//}
//
