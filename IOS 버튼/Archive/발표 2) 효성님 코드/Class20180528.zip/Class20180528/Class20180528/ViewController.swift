//
//  ViewController.swift
//  Class20180528
//
//  Created by H on 2018. 5. 28..
//  Copyright © 2018년 H. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print("view Did Load")
    }
}


